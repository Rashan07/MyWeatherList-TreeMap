package dsa_unit6;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.TreeMap;
/**
 * @author Rashan Buford
 * July 14th 2024
 * Put your name and date and description here.
 */

public class WeatherDriver {

	public static void main(String[] args) {
		System.out.println("Starting weather simulation");

		String fileName = "dsa_unit6/weather.txt";// implementing  WeatherReport objects
		try {
			WeatherReport  weatherReport = new WeatherReport("dsa_unit6/weather.txt");
			WeatherReport weatherReport2 = new WeatherReport("dsa_unit6/weather.txt");
			WeatherReport weatherReport3 = new WeatherReport("dsa_unit6/weather.txt");
			WeatherReport weatherReport4 = new WeatherReport("dsa_unit6/weather.txt");
			//Prints and runs the txt file for both compute List and Tree
			long startTime = System.nanoTime();
			List<WeatherData> listResult = weatherReport.computeByList();
			long endTime = System.nanoTime();
			System.out.println("weatherReport computeByList() time: " + (endTime - startTime) + " nanoseconds");
			System.out.println("weatherReport computeByList() result: " + listResult);
			startTime = System.nanoTime();
			TreeMap<String, WeatherData> treeResult = weatherReport.computeByTree();
			endTime = System.nanoTime();
			System.out.println("weatherReport computeByTree() time: " + (endTime - startTime) + " nanoseconds");
			System.out.println("weatherReport computeByTree() result: " + treeResult);
			long startTime2 = System.nanoTime();
			List<WeatherData> listResult2 = weatherReport2.computeByList();
			long endTime2 = System.nanoTime();
			System.out.println("weatherReport2 computeByList() time: " + (endTime2 - startTime2) + " nanoseconds");
			System.out.println("weatherReport2 computeByList() result: " + listResult2);
			startTime2 = System.nanoTime();
			TreeMap<String, WeatherData> treeResult2 = weatherReport2.computeByTree();
			endTime2 = System.nanoTime();
			System.out.println("weatherReport2.computeByTree() time: " + (endTime2 - startTime2) + " nanoseconds");
			System.out.println("weatherReport2 computeByTree() result: " + treeResult2);
			long startTime3 = System.nanoTime();
			List<WeatherData> listResult3 = weatherReport3.computeByList();
			long endTime3 = System.nanoTime();
			System.out.println("weatherReport3 computeByList() time: " + (endTime3 - startTime3) + " nanoseconds");
			System.out.println("weatherReport3 computeByList() result: " + listResult3);
			startTime3 = System.nanoTime();
			TreeMap<String, WeatherData> treeResult3 = weatherReport3.computeByTree();
			endTime3 = System.nanoTime();
			System.out.println("weatherReport3.computeByTree() time: " + (endTime3 - startTime3) + " nanoseconds");
			System.out.println("weatherReport3 computeByTree() result: " + treeResult3);
			long startTime4 = System.nanoTime();
			List<WeatherData> listResult4 = weatherReport4.computeByList();
			long endTime4 = System.nanoTime();
			System.out.println("weatherReport4 computeByList() time: " + (endTime4 - startTime4) + " nanoseconds");
			System.out.println("weatherReport4 computeByList() result: " + listResult4);
			startTime4 = System.nanoTime();
			TreeMap<String, WeatherData> treeResult4 = weatherReport4.computeByTree();
			endTime4 = System.nanoTime();
			System.out.println("weatherReport4.computeByTree() time: " + (endTime4 - startTime4) + " nanoseconds");
			System.out.println("weatherReport4 computeByTree() result: " + treeResult4);


		}

		catch (FileNotFoundException e ) {
			System.out.println("Can't find file " + fileName);
		}
		catch (Exception e) {
			System.out.println("Other error: " + e.getMessage());
		}
		System.out.println("Finished simulation has concluded");
	}

}

