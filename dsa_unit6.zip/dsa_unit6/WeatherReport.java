package dsa_unit6;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.util.*;

public class WeatherReport {
    private List<WeatherData> weatherDataList;


    public WeatherReport() {
        // linked List objects
        this.weatherDataList = new LinkedList<>();
        weatherDataList = new LinkedList<WeatherData>();
        weatherDataList.add(new WeatherData("City1", "State1", "Winter",5.0));
        weatherDataList.add(new WeatherData("City2", "State2", "Spring",61.0));
        weatherDataList.add(new WeatherData("City3", "State3", "Summer",95.0));
        weatherDataList.add(new WeatherData("City4", "State4", "Fall",72.0));
        weatherDataList.add(new WeatherData("City5", "State5", "Winter",24.0));
        weatherDataList.add(new WeatherData("City6", "State6", "Spring",64.0));
        weatherDataList.add(new WeatherData("City7", "State7", "Summer",80.0));
        weatherDataList.add(new WeatherData("City8", "State8", "Fall",75.0));


    }

    public WeatherReport(String filename) throws FileNotFoundException, IOException {
        weatherDataList = new LinkedList<WeatherData>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;

            br.readLine();

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                String city = data[1];
                String state = data[10];
                double temperature = Double.parseDouble(data[6]) + Double.parseDouble(data[7]) / 2;
                String season = getSeason(data[4]);


                weatherDataList.add(new WeatherData(city, state, season, temperature));
            }
        } catch (IOException e) {
            System.out.println("Error reading file" + e.getMessage());
            throw e;
            //e.printStackTrace();
        }
    }
    // Inplementation tell what season it is
    public String getSeason(String date){
        String[] parts = date.split("/");
        int month = Integer.parseInt(parts[0]);

        if (month >= 3 && month <= 5) {
            return "Spring";

        } else if (month >= 6 && month <= 8) {
            return "Summer";

        } else if(month >= 9 && month <= 11)  {
            return "Fall";
        } else {
            return "Winter";
        }
    }

    // boolean for sorting by city,temp etc
    public boolean isSortedByCity() {
        for (int i = 1; i < weatherDataList.size(); i++) {
            if (weatherDataList.get(i).getCity().equals(weatherDataList.get(i - 1).getCity())) {
                return false;
            }
        }
        return true;
    }

    /*
     * Comparator to sort by the city stored in a Weatherdata object
     */
    class SortByCity implements Comparator<WeatherData> {
        // Used for sorting in ascending order of City
        public int compare(WeatherData w1, WeatherData w2) {
            return w1.getCity().compareTo(w2.getCity());
        }
    }

    /*
     * Comparator to sort  temperature stored in a weatherdata object
     */
    class SortByTemp implements Comparator<WeatherData> {
        // Used for sorting in ascending order of weatherdata
        public int compare(WeatherData w1, WeatherData w2) {
            return Double.compare(w1.getTemperature(), w2.getTemperature());
        }
    }
//  computeBylsi method for calculate average temp for season
    public List<WeatherData> computeByList(){
        List<WeatherData> averages = new LinkedList<>();
        for (WeatherData data : weatherDataList) {
            String key = data.getCity() + "," + data.getSeason();
            boolean found = false;
            for (WeatherData seasonAVG : averages) {
                if (seasonAVG.getCity().equals(data.getCity()) && seasonAVG.getSeason().equals(data.getSeason())) {
                    double totalTemperature = seasonAVG.getTemperature() * seasonAVG.getCount()+ data.getTemperature();
                    seasonAVG.setCount(seasonAVG.getCount() + 1);
                    seasonAVG.setTemperature(totalTemperature / seasonAVG.getCount());
                    found = true;
                    break;
                }
            }
            //checks if weatherdata objects been found 
            if (!found) {
                WeatherData newData = new WeatherData(data.getCity(), data.getState(), data.getSeason().name(), data.getTemperature());
                newData.setCount(1);
                averages.add(newData);
            }
        }
        return averages;
    }
    // The Tree Map method similar to List
    public TreeMap<String, WeatherData> computeByTree(){
        TreeMap<String, WeatherData> averages = new TreeMap<>();
        for (WeatherData data : weatherDataList) {
            String key = data.getCity() + "," + data.getSeason();
            if (!averages.containsKey(key)) {
                WeatherData newData = new WeatherData(data.getCity(), data.getState(), data.getSeason().name(), data.getTemperature());
                newData.setCount(1);
                averages.put(key, newData);
            }
            else {
                WeatherData existingData = averages.get(key);
                double totalTemperature = existingData.getTemperature() * existingData.getCount() + data.getTemperature();
                existingData.setCount(existingData.getCount() + 1);
                existingData.setTemperature(totalTemperature / existingData.getCount());
            }
        }
        return averages;
    }



    public void sortwithCollections( String by) {
        if (by.equals("City")){
            Collections.sort(weatherDataList, new SortByCity());
        } else if (by.equals("Temperature")) {
            Collections.sort(weatherDataList, new SortByTemp());
        }
    }
    public void sortwithMerge( String by) { // Custom Sort routine
        Comparator<WeatherData> comparator = new WeatherReport.SortByTemp();
        if (by.equals("City")) {
            comparator = new WeatherReport.SortByCity();
        } else if (by.equals("Temperature")) {
            comparator = new WeatherReport.SortByTemp();
        } else {
            throw new IllegalArgumentException("Invalid sort parameter: " + by);
        }
        long startTime = System.nanoTime();


        System.out.println("The merge sort by" + by);

        Merge.sort(weatherDataList, comparator);

        long endTime = System.nanoTime();

        long elapsedTime = endTime - startTime;
        System.out.println("Timing of the Merge sort" + by + ": " + elapsedTime + " nanaoseconds" );
    }

    public boolean isSortedByTemp() {
        for (int i = 1; i < weatherDataList.size(); i++) {

            if (weatherDataList.get(i).getTemperature() < weatherDataList.get(i - 1).getTemperature()) {
                return false;
            }
        }
        return true;
    }
}
class Merge{
    public static void sort(List<WeatherData> weatherDataList, Comparator<WeatherData> comparator) {
        if (weatherDataList.size() <= 1) {
            return;
        }

        List<WeatherData> first = new ArrayList<>(weatherDataList.subList(0,weatherDataList.size() / 2));
        List<WeatherData> second = new ArrayList<>(weatherDataList.subList(weatherDataList.size() / 2, weatherDataList.size()));

        sort(first, comparator);
        sort(second, comparator);

        merge(first, second, weatherDataList, comparator);
    }
    private static void merge(List<WeatherData> first, List<WeatherData> second, List<WeatherData> weatherDataList, Comparator<WeatherData> comparator) {
        int iFirst = 0;
        int iSecond = 0;
        int iMerged = 0;

        // Compare elements and move smaller element into result list
        while (iFirst < first.size() && iSecond < second.size()) {
            if (comparator.compare(first.get(iFirst), second.get(iSecond)) < 0) {
                weatherDataList.set(iMerged, first.get(iFirst));
                iFirst++;
            } else {
                weatherDataList.set(iMerged, second.get(iSecond));
                iSecond++;
            }
            iMerged++;
        }
        // handles remaining  elements
        while (iFirst < first.size()) {
            weatherDataList.set(iMerged, first.get(iFirst));
            iFirst++;
            iMerged++;
        }

        while (iSecond < second.size()) { //
            weatherDataList.set(iMerged, second.get(iSecond));
            iSecond++;
            iMerged++;
        }

    }
}
