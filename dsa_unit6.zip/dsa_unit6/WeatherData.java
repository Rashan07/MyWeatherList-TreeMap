package dsa_unit6;
import java.util.LinkedList;
import java.time.LocalDate;

//Weather data declaration
public class WeatherData {
    private String city;
    private String state;
    private double temperature;
    private Season season;
    private int count;


// weather data constructor
    public WeatherData(String city, String state, String season, double temperature) {
        this.city = city;
        this.state = state;
        this.temperature = temperature;
        this.season = Season.valueOf(season);
        this.count = 0;
    }

    public int getCount() {
        return count;
    }
    public void setCount(int count) {
        this.count = count;
    }
    public String getCity() {

        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }




    public Season getSeason() {
        return season;
    }
    public void setSeason(Season season) {
        this.season = season;
    }
    public double getTemperature() {
        return temperature;
    }
    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    //fixes output to be more readable
    @Override
    public String toString() {
        return "WeatherData{" +
                "city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", temperature=" + temperature +
                ", season=" + season +
                ", count=" + count +
                '}';
    }



}



